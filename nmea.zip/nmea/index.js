const nmea = require("node-nmea");
const mqtt = require("mqtt");

const uri = "mqtt://controller:nodemcu@127.0.0.1:61613";

var cli = mqtt.connect(uri);
var buff = new Buffer([]);

function get_sentenses( income ){
    var all = Buffer.concat( [buff, new Buffer(income, "utf-8")] );
    var messages = all.toString("utf-8");
    var fifo = messages.split("\n").map(l=>l.replace("\r", ""));
    if( fifo[fifo.length-1].length > 0 ) {
	   buff = new Buffer(fifo.pop(), "utf-8");
    }
    else buff = new Buffer([]);
    return fifo;
}

cli.on("connect", function(){
    console.log("connected");
    cli.subscribe("gps");
});

cli.on("message", function (topic, msg) {
    var valid = false;
    var sentenses = get_sentenses(msg);
    if( sentenses.length > 0 ) 
        console.log( sentenses[0] )

    var geom = sentenses
	.map( sentense => nmea.parse(sentense) )
	.filter( o => o.valid )
    .reduce( (r, o) => {
	    if( o.type != "GGA" && o.type != "RMC" ) return r;
	    
	    r.loc = o.loc;
	    r.time = o.datetime.getTime();
	    r.speed = o.speed || r.speed;
	    r.satellites = o.satellites || r.satellites;
	    valid = true;
	    return r;
	}, {});

    if( valid ) {
        console.log( "send", JSON.stringify(geom) ) 
        cli.publish("nmea", JSON.stringify(geom));
    }
});
